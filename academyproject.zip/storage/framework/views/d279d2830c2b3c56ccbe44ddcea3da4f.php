

<?php $__env->startSection('title'); ?> Edit MCQ | <?php echo e($ins_name ?? 'App'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>
    .select2-container .select2-selection--single { height: 38px; line-height: 38px; }
    .note-editor.note-frame { border: 1px solid #ced4da; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<main class="main-content">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-0">Edit MCQ</h2>
            <a href="<?php echo e(route('mcq.index')); ?>" class="btn btn-secondary"><i class="fa fa-arrow-left me-1"></i> Back to List</a>
        </div>

        <form action="<?php echo e(route('mcq.update', $mcq->id)); ?>" method="POST" class="card">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="card-body">
                <?php echo $__env->make('flash_message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                
                <div class="row mb-4 p-3 bg-light rounded border">
                    <h6 class="text-primary mb-3"><i class="fa fa-university me-1"></i> Academic Info</h6>
                    
                    
                    <div class="col-md-3 mb-3">
                        <label>Institute Type</label>
                        <select id="institute_type" class="form-control select2">
                            <option value="">Select Type</option>
                            <option value="school" <?php echo e(optional($mcq->institute)->type == 'school' ? 'selected' : ''); ?>>School</option>
                            <option value="college" <?php echo e(optional($mcq->institute)->type == 'college' ? 'selected' : ''); ?>>College</option>
                            <option value="university" <?php echo e(optional($mcq->institute)->type == 'university' ? 'selected' : ''); ?>>University</option>
                        </select>
                    </div>

                    
                    <div class="col-md-3 mb-3">
                        <label>Institute</label>
                        <select name="institute_id" id="institute_id" class="form-control select2">
                            <option value="">Select Institute</option>
                            
                            <?php $__currentLoopData = $institutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($i->id); ?>" <?php echo e($mcq->institute_id == $i->id ? 'selected' : ''); ?>><?php echo e($i->name_en); ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-3 mb-3">
                        <label>Board</label>
                        <select name="board_id" class="form-control select2">
                            <option value="">Select Board</option>
                            <?php $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($b->id); ?>" <?php echo e($mcq->board_id == $b->id ? 'selected' : ''); ?>><?php echo e($b->name_en); ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label>Academic Year</label>
                        <select name="year_id" class="form-control select2">
                            <option value="">Select Year</option>
                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($y->id); ?>" <?php echo e($mcq->year_id == $y->id ? 'selected' : ''); ?>><?php echo e($y->name_en); ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                
                <div class="row mb-3">
                    <div class="col-md-3 mb-3">
                        <label>Category *</label>
                        <select name="category_id" id="category_id" class="form-control select2" required>
                            <option value="">Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($cat->id); ?>" <?php echo e($mcq->category_id == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->english_name); ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label>Class *</label>
                        <select name="class_id" id="class_id" class="form-control select2" required>
                            <option value="">Select Class</option>
                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <option value="<?php echo e($c->id); ?>" <?php echo e($mcq->class_id == $c->id ? 'selected' : ''); ?>><?php echo e($c->name_en); ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label>Department</label>
                        <select name="class_department_id" id="department_id" class="form-control select2">
                            <option value="">Select Department</option>
                            
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label>Subject *</label>
                        <select name="subject_id" id="subject_id" class="form-control select2" required>
                            <option value="">Select Subject</option>
                            
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label>Chapter</label>
                        <select name="chapter_id" id="chapter_id" class="form-control select2">
                            <option value="">Select Chapter</option>
                            
                        </select>
                    </div>
                    <div class="col-md-8 mb-3">
                        <label>Topic</label>
                        <select name="topic_id" id="topic_id" class="form-control select2">
                            <option value="">Select Topic</option>
                            
                        </select>
                    </div>
                </div>

                <hr>

                
                <div class="mb-3">
                    <label class="fw-bold">Question *</label>
                    <textarea name="question" class="form-control summernote" required><?php echo e($mcq->question); ?></textarea>
                </div>

                <div class="row">
                    <?php for($i=1; $i<=4; $i++): ?>
                    <?php $opt = 'option_'.$i; ?>
                    <div class="col-md-6 mb-3">
                        <div class="input-group">
                            <div class="input-group-text bg-white">
                                <input class="form-check-input mt-0" type="radio" name="answer" value="<?php echo e($i); ?>" <?php echo e($mcq->answer == $i ? 'checked' : ''); ?> required>
                            </div>
                            <input type="text" name="<?php echo e($opt); ?>" class="form-control" value="<?php echo e($mcq->$opt); ?>" required>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>

                
                <div class="row">
                    <div class="col-md-8 mb-3">
                        <label>Tags</label>
                        <select name="tags[]" class="form-control select2" multiple="multiple">
                            <?php if($mcq->tags): ?>
                                <?php $__currentLoopData = $mcq->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tag); ?>" selected><?php echo e($tag); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <option value="1" <?php echo e($mcq->status == 1 ? 'selected' : ''); ?>>Active</option>
                            <option value="0" <?php echo e($mcq->status == 0 ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label>Short Description</label>
                        <textarea name="short_description" class="form-control" rows="3"><?php echo e($mcq->short_description); ?></textarea>
                    </div>
                </div>
            </div>
            <div class="card-footer text-end">
                <button type="submit" class="btn btn-primary"><i class="fa fa-save me-1"></i> Update MCQ</button>
            </div>
        </form>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2({ tags: true, tokenSeparators: [',', ' '] });
        $('.summernote').summernote({ height: 150 });

        var routes = {
            institutes: "<?php echo e(route('mcq.ajax.institutes')); ?>",
            classes: "<?php echo e(route('mcq.ajax.classes')); ?>",
            departments: "<?php echo e(route('mcq.ajax.departments')); ?>",
            subjects: "<?php echo e(route('mcq.ajax.subjects')); ?>",
            chapters: "<?php echo e(route('mcq.ajax.chapters')); ?>",
            topics: "<?php echo e(route('mcq.ajax.topics')); ?>",
        };

        // Saved IDs for pre-filling
        var saved = {
            cls: "<?php echo e($mcq->class_id); ?>",
            dept: "<?php echo e($mcq->class_department_id); ?>",
            sub: "<?php echo e($mcq->subject_id); ?>",
            chap: "<?php echo e($mcq->chapter_id); ?>",
            top: "<?php echo e($mcq->topic_id); ?>"
        };

        // --- 1. Institute Type Change Logic ---
        $('#institute_type').on('change', function(e) {
            if(!e.originalEvent) return; // Prevent clearing on page load
            var type = $(this).val();
            $('#institute_id').html('<option value="">Loading...</option>');
            
            if(type) {
                $.get(routes.institutes, { type: type }, function(res) {
                    var ops = '<option value="">Select Institute</option>';
                    res.forEach(el => ops += `<option value="${el.id}">${el.name_en}</option>`);
                    $('#institute_id').html(ops);
                });
            } else {
                $('#institute_id').html('<option value="">Select Institute</option>');
            }
        });

        // --- 2. Reusable Load Functions (For Edit Mode) ---

        function loadDepartments(clsId, selected = null) {
            $.get(routes.departments, { class_id: clsId }, function(res) {
                var ops = '<option value="">Select Department</option>';
                res.forEach(el => ops += `<option value="${el.id}">${el.name_en}</option>`);
                $('#department_id').html(ops).val(selected).trigger('change.select2'); 
            });
        }

        function loadSubjects(clsId, deptId, selected = null) {
            $.get(routes.subjects, { class_id: clsId, department_id: deptId }, function(res) {
                var ops = '<option value="">Select Subject</option>';
                res.forEach(el => ops += `<option value="${el.id}">${el.name_en}</option>`);
                $('#subject_id').html(ops).val(selected).trigger('change.select2'); 
                
                // If initializing (selected is not null) and chapters dropdown is empty, load chapters
                if(selected && $('#chapter_id').children('option').length <= 1) {
                    loadChapters(selected, clsId, saved.chap);
                }
            });
        }

        function loadChapters(subId, clsId, selected = null) {
            $.get(routes.chapters, { subject_id: subId, class_id: clsId }, function(res) {
                var ops = '<option value="">Select Chapter</option>';
                res.forEach(el => ops += `<option value="${el.id}">${el.name_en}</option>`);
                $('#chapter_id').html(ops).val(selected).trigger('change.select2');

                // Load Topics if chapter is selected
                if(selected && $('#topic_id').children('option').length <= 1) {
                    loadTopics(selected, saved.top);
                }
            });
        }

        function loadTopics(chapId, selected = null) {
            $.get(routes.topics, { chapter_id: chapId }, function(res) {
                var ops = '<option value="">Select Topic</option>';
                res.forEach(el => ops += `<option value="${el.id}">${el.name_en}</option>`);
                $('#topic_id').html(ops).val(selected).trigger('change.select2');
            });
        }

        // --- 3. Init Load (Pre-fill Data) ---
        if(saved.cls) {
            loadDepartments(saved.cls, saved.dept);
            loadSubjects(saved.cls, saved.dept, saved.sub);
        }

        // --- 4. Event Listeners (User Interaction) ---

        // Category -> Class
        $('#category_id').on('change', function(e) {
            if(!e.originalEvent) return;
            var id = $(this).val();
            $('#class_id').html('<option value="">Loading...</option>');
            
            // Reset downstream
            $('#department_id').html('<option value="">Select Department</option>');
            $('#subject_id').html('<option value="">Select Subject</option>');
            $('#chapter_id').html('<option value="">Select Chapter</option>');
            $('#topic_id').html('<option value="">Select Topic</option>');

            if(id) {
                $.get(routes.classes, { category_id: id }, function(res) {
                    var ops = '<option value="">Select Class</option>';
                    res.forEach(el => ops += `<option value="${el.id}">${el.name_en}</option>`);
                    $('#class_id').html(ops);
                });
            } else {
                 $('#class_id').html('<option value="">Select Class</option>');
            }
        });

        // Class -> Department AND Subject
        $('#class_id').on('change', function(e) {
            if(!e.originalEvent) return;
            var clsId = $(this).val();
            
            if(clsId) {
                // Load Departments
                $('#department_id').html('<option value="">Loading...</option>');
                $.get(routes.departments, { class_id: clsId }, function(res) {
                    var ops = '<option value="">Select Department</option>';
                    res.forEach(el => ops += `<option value="${el.id}">${el.name_en}</option>`);
                    $('#department_id').html(ops);
                });

                // Load Subjects (Initially based on Class only)
                loadSubjects(clsId, null);
            } else {
                $('#department_id').html('<option value="">Select Department</option>');
                $('#subject_id').html('<option value="">Select Subject</option>');
            }
        });

        // Department -> Reload Subject
        $('#department_id').on('change', function(e) {
            if(!e.originalEvent) return;
            loadSubjects($('#class_id').val(), $(this).val());
        });

        // Subject -> Chapter
        $('#subject_id').on('change', function(e) {
            if(!e.originalEvent) return;
            var subId = $(this).val();
            var clsId = $('#class_id').val();
            loadChapters(subId, clsId);
        });

        // Chapter -> Topic
        $('#chapter_id').on('change', function(e) {
            if(!e.originalEvent) return;
            loadTopics($(this).val());
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\project2025\htdocs\2026\academyproject\resources\views/admin/mcq/edit.blade.php ENDPATH**/ ?>