<?php
     $usr = Auth::user();
?>

<nav id="sidebar">
    <div class="sidebar-header">
        <img src="<?php echo e(asset('/')); ?><?php echo e($front_logo_name); ?>" alt="<?php echo e($ins_name); ?> Logo" class="img-fluid">
    </div>
    
    <ul class="nav flex-column" id="sidebar-menu">
        
        <?php if($usr->can('dashboardView')): ?>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Route::is('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">
                <i data-feather="grid"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <?php endif; ?>

        
        <?php if(isset($globalFeatures)): ?>
            <?php $__currentLoopData = $globalFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                
                <li class="sidebar-title">
                    <span><?php echo e($feature->english_name ?? $feature->bangla_name); ?></span>
                </li>

                
                
                
                <?php if($feature->slug == '1st-12th-grade' || $feature->english_name == '1st-12th Grade'): ?>
                <li class="nav-item">
                    <a class="nav-link collapsed" href="#questionBankSubmenu" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="questionBankSubmenu">
                        <i data-feather="book-open"></i>
                        <span>Question Bank</span>
                        <i data-feather="chevron-down" class="ms-auto"></i>
                    </a>
                    
                    <ul class="collapse list-unstyled <?php echo e(Route::is('mcq.*') ? 'show' : ''); ?>" id="questionBankSubmenu" data-bs-parent="#sidebar-menu">
                        
                        
                        <li>
                            <a class="nav-link collapsed" href="#mcqSubmenu" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="mcqSubmenu">
                                <span>MCQ</span>
                                <i data-feather="chevron-down" class="ms-auto" style="width: 15px; height: 15px;"></i>
                            </a>
                            
                            <ul class="collapse list-unstyled <?php echo e(Route::is('mcq.*') ? 'show' : ''); ?>" id="mcqSubmenu" data-bs-parent="#questionBankSubmenu">
                                <li>
                                    <a class="nav-link <?php echo e(Route::is('mcq.create') ? 'active' : ''); ?>" href="<?php echo e(route('mcq.create')); ?>" style="padding-left: 3rem;">
                                        <i class="fa fa-plus-circle me-2" style="font-size: 10px;"></i> Add New MCQ
                                    </a>
                                </li>
                                <li>
                                    <a class="nav-link <?php echo e(Route::is('mcq.index') ? 'active' : ''); ?>" href="<?php echo e(route('mcq.index')); ?>" style="padding-left: 3rem;">
                                        <i class="fa fa-list me-2" style="font-size: 10px;"></i> MCQ List
                                    </a>
                                </li>
                            </ul>
                        </li>

                        
                        
                        <li>
                            <a class="nav-link" href="#">Board Question</a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        
        <?php if($usr->can('featureView') || $usr->can('featureAdd') || 
             $usr->can('categoryView') || $usr->can('categoryAdd') || 
             $usr->can('classDepartmentView') || $usr->can('classDepartmentAdd') ||
             $usr->can('schoolClassView') || $usr->can('schoolClassAdd') ||
             $usr->can('instituteAdd') || $usr->can('instituteView') ||
             $usr->can('academicYearView') || $usr->can('academicYearAdd') ||
             $usr->can('boardView') || $usr->can('boardAdd') ||
             $usr->can('subjectView') || $usr->can('subjectAdd')): ?> 
        
        <li class="nav-item">
            <a class="nav-link" href="#masterSetupSubmenu" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="masterSetupSubmenu">
                <i data-feather="layers"></i>
                <span>Master Setup</span>
                <i data-feather="chevron-down" class="ms-auto"></i>
            </a>
            
            <ul class="collapse list-unstyled <?php echo e(Route::is('classDepartment.*') || Route::is('institute.*') || Route::is('academicYear.*') || Route::is('board.*') || Route::is('topic.*') || Route::is('chapter.*') || Route::is('section.*') || Route::is('subject.*') ||  Route::is('feature.*') || Route::is('category.*') || Route::is('schoolClass.*') ? 'show' : ''); ?>" id="masterSetupSubmenu" data-bs-parent="#sidebar-menu">

                
                <?php if($usr->can('boardAdd') || $usr->can('boardView') || $usr->can('boardDelete') || $usr->can('boardUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('board.index') ? 'active' : ''); ?>" href="<?php echo e(route('board.index')); ?>">Board</a></li>
                <?php endif; ?>

                
                <?php if($usr->can('academicYearAdd') || $usr->can('academicYearView') || $usr->can('academicYearDelete') || $usr->can('academicYearUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('academicYear.index') ? 'active' : ''); ?>" href="<?php echo e(route('academicYear.index')); ?>">Academic Year</a></li>
                <?php endif; ?>

                
                <?php if($usr->can('instituteAdd') || $usr->can('instituteView')): ?>
                <li><a class="nav-link <?php echo e(Route::is('institute.index') ? 'active' : ''); ?>" href="<?php echo e(route('institute.index')); ?>">Institute</a></li>
                <?php endif; ?>

                
                <?php if($usr->can('featureAdd') || $usr->can('featureView') || $usr->can('featureDelete') || $usr->can('featureUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('feature.index') ? 'active' : ''); ?>" href="<?php echo e(route('feature.index')); ?>">Feature</a></li>
                <?php endif; ?>

                
                <?php if($usr->can('categoryAdd') || $usr->can('categoryView') || $usr->can('categoryDelete') || $usr->can('categoryUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('category.index') ? 'active' : ''); ?>" href="<?php echo e(route('category.index')); ?>">Category</a></li>
                <?php endif; ?> 

                
                <?php if($usr->can('schoolClassAdd') || $usr->can('schoolClassView') || $usr->can('schoolClassDelete') || $usr->can('schoolClassUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('schoolClass.index') ? 'active' : ''); ?>" href="<?php echo e(route('schoolClass.index')); ?>">Class</a></li>
                <?php endif; ?>

                
                <?php if($usr->can('classDepartmentAdd') || $usr->can('classDepartmentView') || $usr->can('classDepartmentDelete') || $usr->can('classDepartmentUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('classDepartment.index') ? 'active' : ''); ?>" href="<?php echo e(route('classDepartment.index')); ?>">Class Department</a></li>
                <?php endif; ?>

                
                <?php if($usr->can('subjectAdd') || $usr->can('subjectView') || $usr->can('subjectDelete') || $usr->can('subjectUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('subject.index') ? 'active' : ''); ?>" href="<?php echo e(route('subject.index')); ?>">Subject</a></li>
                <?php endif; ?>

                
                <?php if($usr->can('sectionAdd') || $usr->can('sectionView') || $usr->can('sectionDelete') || $usr->can('sectionUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('section.index') ? 'active' : ''); ?>" href="<?php echo e(route('section.index')); ?>">Section</a></li>
                <?php endif; ?>

                
                <?php if($usr->can('chapterAdd') || $usr->can('chapterView') || $usr->can('chapterDelete') || $usr->can('chapterUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('chapter.index') ? 'active' : ''); ?>" href="<?php echo e(route('chapter.index')); ?>">Chapter</a></li>
                <?php endif; ?>

                
                <?php if($usr->can('topicAdd') || $usr->can('topicView') || $usr->can('topicDelete') || $usr->can('topicUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('topic.index') ? 'active' : ''); ?>" href="<?php echo e(route('topic.index')); ?>">Topic</a></li>
                <?php endif; ?>

            </ul>
        </li>
        <?php endif; ?>

        
        <?php if($usr->can('aboutUsAdd') || $usr->can('aboutUsView') || $usr->can('aboutUsDelete') || $usr->can('aboutUsUpdate') || $usr->can('messageAdd') || $usr->can('messageView') || $usr->can('messageDelete') || $usr->can('messageUpdate') || $usr->can('extraPageAdd') || $usr->can('extraPageView') || $usr->can('extraPageDelete') || $usr->can('extraPageUpdate') || $usr->can('socialLinkAdd') || $usr->can('socialLinkView') || $usr->can('socialLinkDelete') || $usr->can('socialLinkUpdate') || $usr->can('reviewAdd') || $usr->can('reviewView') || $usr->can('reviewDelete') || $usr->can('reviewUpdate')): ?>
        <li class="sidebar-title">
            <span>Extra Content</span>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#cmsSubmenu" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="cmsSubmenu">
                <i data-feather="file-text"></i>
                <span>Content</span>
                <i data-feather="chevron-down" class="ms-auto"></i>
            </a>
            <ul class="collapse list-unstyled <?php echo e(Route::is('footer-banner.index') || Route::is('hero-right-slider.*') || Route::is('hero-left-slider.index') || Route::is('hero-left-slider.create') || Route::is('hero-left-slider.edit') || Route::is('review.index') || Route::is('review.edit') || Route::is('review.show') || Route::is('extraPage.index') || Route::is('message.index') || Route::is('aboutUs.index') || Route::is('socialLink.index') || Route::is('settings.analytics.index') || Route::is('homepage-section.index') || Route::is('featured-category.index') || Route::is('highlight-product.index') || Route::is('offer-section.control.index') || Route::is('slider.control.index') || Route::is('sidebar-menu.control.index') || Route::is('frontend.control.index') ? 'show' : ''); ?>" id="cmsSubmenu" data-bs-parent="#sidebar-menu">

                <?php if($usr->can('reviewAdd') || $usr->can('reviewView') || $usr->can('reviewDelete') || $usr->can('reviewUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('review.index') || Route::is('review.edit') || Route::is('review.show') ? 'active' : ''); ?>" href="<?php echo e(route('review.index')); ?>">Review</a></li>
                <?php endif; ?>

                <?php if($usr->can('socialLinkAdd') || $usr->can('socialLinkView') || $usr->can('socialLinkDelete') || $usr->can('socialLinkUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('socialLink.index') || Route::is('socialLink.edit') || Route::is('socialLink.create') ? 'active' : ''); ?>" href="<?php echo e(route('socialLink.index')); ?>">Social Link</a></li>
                <?php endif; ?>

                <?php if($usr->can('extraPageAdd') || $usr->can('extraPageView') || $usr->can('extraPageDelete') || $usr->can('extraPageUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('extraPage.index') || Route::is('extraPage.edit') || Route::is('extraPage.create') ? 'active' : ''); ?>" href="<?php echo e(route('extraPage.index')); ?>">Extra Page</a></li>
                <?php endif; ?>

                <?php if($usr->can('messageAdd') || $usr->can('messageView') || $usr->can('messageDelete') || $usr->can('messageUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('message.index') || Route::is('message.edit') || Route::is('message.create') ? 'active' : ''); ?>" href="<?php echo e(route('message.index')); ?>">Message</a></li>
                <?php endif; ?>

                <?php if($usr->can('aboutUsAdd') || $usr->can('aboutUsView') || $usr->can('aboutUsDelete') || $usr->can('aboutUsUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('aboutUs.index') || Route::is('aboutUs.edit') || Route::is('aboutUs.create') ? 'active' : ''); ?>" href="<?php echo e(route('aboutUs.index')); ?>">About Us</a></li>
                <?php endif; ?>
            </ul>
        </li>
        <?php endif; ?>

        
        <?php if($usr->can('userAdd') || $usr->can('userView') || $usr->can('userDelete') || $usr->can('userUpdate') || $usr->can('designationAdd') || $usr->can('designationView') || $usr->can('designationDelete') || $usr->can('designationUpdate') || $usr->can('branchAdd') || $usr->can('branchView') || $usr->can('branchDelete') || $usr->can('branchUpdate')): ?>
        <li class="sidebar-title">
            <span>Settings</span>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="#accountSettingsSubmenu" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="accountSettingsSubmenu">
                <i data-feather="user"></i>
                <span>Account</span>
                <i data-feather="chevron-down" class="ms-auto"></i>
            </a>
            <ul class="collapse list-unstyled <?php echo e(Route::is('users.show') || Route::is('users.index') || Route::is('users.edit') || Route::is('users.create') || Route::is('branch.index') || Route::is('branch.edit') || Route::is('branch.create') || Route::is('designation.index') || Route::is('designation.edit') || Route::is('designation.create') ? 'show' : ''); ?>" id="accountSettingsSubmenu" data-bs-parent="#sidebar-menu">

                <?php if($usr->can('designationAdd') || $usr->can('designationView') || $usr->can('designationDelete') || $usr->can('designationUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('designation.index') || Route::is('designation.edit') || Route::is('designation.create') ? 'active' : ''); ?>" href="<?php echo e(route('designation.index')); ?>">Designation</a></li>
                <?php endif; ?>

                <?php if($usr->can('userAdd') || $usr->can('userView') || $usr->can('userDelete') || $usr->can('userUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('users.show') || Route::is('users.index') || Route::is('users.edit') || Route::is('users.create') ? 'active' : ''); ?>" href="<?php echo e(route('users.index')); ?>">User</a></li>
                <?php endif; ?>

            </ul>
        </li>
        <?php endif; ?>

        <?php if($usr->can('permissionAdd') || $usr->can('permissionView') || $usr->can('permissionDelete') || $usr->can('permissionUpdate') || $usr->can('roleAdd') || $usr->can('roleView') || $usr->can('roleUpdate') || $usr->can('roleDelete') || $usr->can('panelSettingAdd') || $usr->can('panelSettingView') || $usr->can('panelSettingDelete') || $usr->can('panelSettingUpdate')): ?>
        <li class="nav-item mb-5">
            <a class="nav-link" href="#generalSettingsSubmenu" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="generalSettingsSubmenu">
                <i data-feather="settings"></i>
                <span>General</span>
                <i data-feather="chevron-down" class="ms-auto"></i>
            </a>
            <ul class="collapse list-unstyled <?php echo e(Route::is('roles.show') || Route::is('permissions.index') || Route::is('permissions.edit') || Route::is('permissions.create') || Route::is('roles.index') || Route::is('roles.edit') || Route::is('roles.create') || Route::is('systemInformation.index') || Route::is('systemInformation.edit') || Route::is('systemInformation.create') ? 'show' : ''); ?>" id="generalSettingsSubmenu" data-bs-parent="#sidebar-menu">

                <?php if($usr->can('panelSettingAdd') || $usr->can('panelSettingView') || $usr->can('panelSettingDelete') || $usr->can('panelSettingUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('systemInformation.index') || Route::is('systemInformation.edit') || Route::is('systemInformation.create') ? 'active' : ''); ?>" href="<?php echo e(route('systemInformation.index')); ?>">Panel Settings</a></li>
                <?php endif; ?>

                <?php if($usr->can('roleAdd') || $usr->can('roleView') || $usr->can('roleEdit') || $usr->can('roleDelete')): ?>
                <li><a class="nav-link <?php echo e(Route::is('roles.show') || Route::is('roles.index') || Route::is('roles.edit') || Route::is('roles.create') ? 'active' : ''); ?>" href="<?php echo e(route('roles.index')); ?>">Role Management</a></li>
                <?php endif; ?>

                <?php if($usr->can('permissionAdd') || $usr->can('permissionView') || $usr->can('permissionDelete') || $usr->can('permissionUpdate')): ?>
                <li><a class="nav-link <?php echo e(Route::is('permissions.index') || Route::is('permissions.edit') || Route::is('permissions.create') ? 'active' : ''); ?>" href="<?php echo e(route('permissions.index')); ?>">Permission Management</a></li>
                <?php endif; ?>

            </ul>
        </li>
        <?php endif; ?>
    </ul>
</nav><?php /**PATH F:\project2025\htdocs\2026\academyproject\resources\views/admin/include/sidebar.blade.php ENDPATH**/ ?>