<?php
     $usr = Auth::user();
 ?>

 <nav class="navbar navbar-expand-lg navbar-light">
                <div class="container-fluid">
                    <!-- Left Side: Toggler and Title -->
                    <div class="d-flex align-items-center">
                        <button class="sidebar-toggler-btn me-3" type="button" id="sidebarToggleBtn" title="Toggle Sidebar">
                            <i data-feather="menu"></i>
                        </button>
                        <div class="d-none d-lg-flex align-items-baseline">
                            <h5 class="mb-0 text-primary me-3" style="color: var(--primary-color) !important;"><?php echo e($ins_name); ?></h5>
                            <small id="currentDate" class="text-muted"></small>
                        </div>
                    </div>

                    <!-- Right Side: Buttons and Profile -->
                    <div class="d-flex align-items-center">
                        <!-- Clear Cache Button -->
                        <a href="<?php echo e(url('/clear')); ?>" class="btn btn-sm btn-danger text-white me-3" title="Clear Cache">
                            <i data-feather="refresh-cw" style="width:16px; height:16px;"></i>
                            <span class="d-none d-sm-inline ms-1">Clear Cache</span>
                        </a>


                        <!-- Profile Dropdown -->
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">

                                        <?php if(empty(Auth::user()->image)): ?>
                  
                     <img src="<?php echo e(asset('/')); ?>public/No_Image_Available.jpg" alt="Admin" width="40" height="40" class="rounded-circle">
                    <?php else: ?>
                    <img src="<?php echo e(asset('/')); ?><?php echo e(Auth::user()->image); ?>" alt="Admin" width="40" height="40" class="rounded-circle">
                    <?php endif; ?>

                               
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-custom" aria-labelledby="navbarDropdown">
                               <?php if($usr->can('profileView')): ?>
                                <li><a class="dropdown-item" href="<?php echo e(route('profileView')); ?>"><i data-feather="user"></i>Profile</a></li>
                               <?php endif; ?>
                               <?php if($usr->can('profileSetting')): ?>
                                <li><a class="dropdown-item" href="<?php echo e(route('profileSetting')); ?>"><i data-feather="settings"></i>Settings</a></li>
                                 <?php endif; ?>

                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault();
                      document.getElementById('admin-logout-form').submit();"><i data-feather="log-out"></i>Logout</a></li>
                       <form id="admin-logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>

 

<?php /**PATH F:\project2025\htdocs\2026\academyproject\resources\views/admin/include/header.blade.php ENDPATH**/ ?>