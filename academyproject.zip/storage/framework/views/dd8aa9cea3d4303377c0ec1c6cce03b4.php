<ul class="nav nav-pills mb-3" id="pills-tab-<?php echo e($type); ?>" role="tablist">
    <li class="nav-item">
        <button class="nav-link active btn-sm" data-bs-toggle="pill" data-bs-target="#table-view-<?php echo e($type); ?>">List View</button>
    </li>
    <li class="nav-item">
        <button class="nav-link btn-sm" data-bs-toggle="pill" data-bs-target="#sort-view-<?php echo e($type); ?>">Drag & Drop Sort</button>
    </li>
</ul>

<div class="tab-content">
    
    <div class="tab-pane fade show active" id="table-view-<?php echo e($type); ?>">
        <div class="table-responsive">
            <table class="table table-hover table-bordered align-middle">
                <thead>
                    <tr>
                        <th>Sl</th>
                        <th>Name (EN)</th>
                        <th>Name (BN)</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="tableBody_<?php echo e($type); ?>"></tbody>
            </table>
        </div>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <div class="text-muted" id="info_<?php echo e($type); ?>"></div>
            <nav><ul class="pagination justify-content-center mb-0" id="pagination_<?php echo e($type); ?>"></ul></nav>
        </div>
    </div>

    
    <div class="tab-pane fade" id="sort-view-<?php echo e($type); ?>">
        <div class="alert alert-info"><i class="fa fa-info-circle me-1"></i> Drag items to reorder <?php echo e(ucfirst($type)); ?>s.</div>
        <ul class="sortable-list" id="sortable-<?php echo e($type); ?>">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li data-id="<?php echo e($item->id); ?>">
                <div class="d-flex align-items-center gap-3">
                    <i class="fa fa-bars text-muted"></i>
                    <strong><?php echo e($item->name_en); ?></strong> (<?php echo e($item->name_bn); ?>)
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div><?php /**PATH F:\project2025\htdocs\2026\academyproject\resources\views/admin/institute/tab_content.blade.php ENDPATH**/ ?>