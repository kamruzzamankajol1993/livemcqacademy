<?php $__env->startSection('title'); ?>
Role Management | <?php echo e($ins_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .permission-group {
        border: 1px solid #e0e0e0;
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 20px;
    }
    .permission-group-title {
        border-bottom: 2px solid #0d6efd;
        padding-bottom: 10px;
        margin-bottom: 15px;
        font-weight: 600;
        color: #333;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<main class="main-content">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="h4 mb-0">Create New Role</h2>
            <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-outline-primary btn-sm">
                <i class="fa-solid fa-arrow-left"></i> Back to List
            </a>
        </div>

        <div class="card">
            <div class="card-header bg-light">
                <h5 class="card-title mb-0">Role Details</h5>
            </div>
            <div class="card-body">
                <?php echo $__env->make('flash_message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <form method="POST" action="<?php echo e(route('roles.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        
                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                                <label for="name" class="form-label"><strong>Role Name:</strong></label>
                                <input type="text" name="name" id="name" placeholder="e.g., Editor" class="form-control" required>
                            </div>
                        </div>

                        
                        <div class="col-md-12">
                            <div class="form-group permission-group">
                                <strong class="permission-group-title d-block">Assign Permissions:</strong>
                                
                                
                                <div class="form-check bg-light p-3 rounded mb-3">
                                    <input type="checkbox" id="checkAll" class="form-check-input">
                                    <label for="checkAll" class="form-check-label fw-bold">Select All Permissions</label>
                                </div>
                                <hr>

                                
                                <div class="row">
                                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 col-sm-6 mb-2">
                                        <div class="form-check">
                                            <input type="checkbox" name="permission[<?php echo e($value->id); ?>]" value="<?php echo e($value->id); ?>" class="form-check-input permission-checkbox" id="perm_<?php echo e($value->id); ?>">
                                            <label class="form-check-label" for="perm_<?php echo e($value->id); ?>"><?php echo e($value->name); ?></label>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                        
                        <div class="col-12 text-center mt-3">
                            <button type="submit" class="btn btn-primary">
                                <i class="fa-solid fa-floppy-disk"></i> Submit
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $(document).ready(function() {
        // "Select All" checkbox functionality
        $("#checkAll").click(function() {
            $('.permission-checkbox').prop('checked', $(this).prop('checked'));
        });

        // Individual permission checkbox functionality
        $(".permission-checkbox").change(function() {
            if (!$(this).prop("checked")) {
                $("#checkAll").prop("checked", false);
            }
            // Optional: check "All" if all permissions are selected
            if ($('.permission-checkbox:checked').length === $('.permission-checkbox').length) {
                $('#checkAll').prop('checked', true);
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\project2025\htdocs\2026\academyproject\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>