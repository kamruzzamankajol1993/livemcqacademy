<?php $__env->startSection('title'); ?>

Permission Management | <?php echo e($ins_name); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

 <main class="main-content">
                <div class="container-fluid">
                    <h2 class="mb-4">Update Permission</h2>

                    <div class="card">
                        <div class="card-body">
                           <form id="form" method="post" action="<?php echo e(route('permissions.update',$pers)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="mb-4">
                        <label for="formrow-email-input" class="form-label">Group Name</label>
                        <input type="text" name="group_name" value="<?php echo e($pers); ?>"  class="form-control" placeholder="Group Name" required>
                        <small></small>
                    </div>
                </div>
                <div class="col-md-12">

                    <table class="table table-bordered" id="dynamicAddRemove">
                        <tr>
                            <th>Permission Name</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $persEdit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j=>$allPermissionList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($j == 0 ): ?>
                        <tr id="mDelete<?php echo e($j+50000); ?>">
                            <td><input type="text" name="name[]" value="<?php echo e($allPermissionList->name); ?>" placeholder="Enter Ename" id="name<?php echo e($j+50000); ?>" class="form-control" />
                            </td>
                            <td><button type="button" name="add" id="dynamic-ar" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></button></td>
                        </tr>
                        <?php else: ?>
                        <tr id="mDelete<?php echo e($j+50000); ?>">
                            <td><input type="text" name="name[]" value="<?php echo e($allPermissionList->name); ?>" placeholder="Enter Ename" id="name<?php echo e($j+50000); ?>" class="form-control" />
                            </td>
                            <td><button type="button"  class="btn btn-danger btn-sm remove-input-field"><i class="fa fa-trash"></i></button></td>
                        </tr>

                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                </div>






            </div>






            <div>
                <button type="submit" class="btn btn-primary btn-sm w-md mt-3">Update</button>
            </div>


        </form>
                        </div>
                    </div>
                </div>
               
            </main>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    var i = 0;
    $("#dynamic-ar").click(function () {
        ++i;
        $("#dynamicAddRemove").append('<tr><td><input type="text" name="name[]" id="name'+i+'" placeholder="Permission Name" class="form-control" /></td><td><button type="button" class="btn btn-danger btn-sm remove-input-field"><i class="fa fa-trash"></i></button></td></tr>'
            );
    });
    $(document).on('click', '.remove-input-field', function () {
        $(this).parents('tr').remove();
    });
</script>


<script type="text/javascript">
    var i = 0;
    $("[id^=dynamic-arr]").click(function () {
        ++i;
        var main_id = $(this).attr('id');
        var id_for_pass = main_id.slice(11);

        $("#dynamicAddRemovee"+id_for_pass).append('<tr id="mDelete'+i+'"><td><input type="text" name="name[]" id="name'+i+'" placeholder="Permission Name" class="form-control" /></td><td><button type="button" id="remove-input-field'+i+'" class="btn btn-danger btn-sm">Delete</button></td></tr>'
            );
    });


    $(document).on('click', '[id^=remove-input-fieldd]', function () {

        var main_id = $(this).attr('id');
        var id_for_pass = main_id.slice(19);

       // alert(id_for_pass);

        $("#mDelete"+id_for_pass).remove();

        //$(this).parents('tr').remove();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\project2025\htdocs\2026\academyproject\resources\views/admin/permission/edit.blade.php ENDPATH**/ ?>